// Конфиг цен квиза «Твой план гладкости».
// ⚠️ ЕДИНСТВЕННОЕ место, где живут цены квиза. При изменении прайса — править тут.
// Подтверждено владельцем: акционные цены первого визита, Комплекс №1 (PREMIUM 350,
// курс 9 = 245/процедуру). Остальные базовые цены — публичные цены сайта («от»),
// курс 9 считается как −30% от базовой с приставкой «от».

export type ZoneId =
  | 'bikini'
  | 'podmyshki'
  | 'nogi'
  | 'goleni'
  | 'ruki'
  | 'lico'
  | 'vse_telo';

export const ZONES: { id: ZoneId; label: string }[] = [
  { id: 'bikini', label: 'Глубокое бикини' },
  { id: 'podmyshki', label: 'Подмышки' },
  { id: 'nogi', label: 'Ноги полностью' },
  { id: 'goleni', label: 'Голени' },
  { id: 'ruki', label: 'Руки' },
  { id: 'lico', label: 'Лицо (верхняя губа / подбородок)' },
  { id: 'vse_telo', label: 'Всё тело' }
];

// Базовые («от») цены за процедуру по зонам с сайта. null = в прайсе сайта нет —
// TODO: подтвердить с владельцем.
export const ZONE_BASE_PRICE: Record<ZoneId, number | null> = {
  bikini: 160,
  podmyshki: 150,
  nogi: 250,
  goleni: null, // TODO: подтвердить цену
  ruki: null, // TODO: подтвердить цену
  lico: 75,
  vse_telo: 500
};

export const COURSE9_DISCOUNT = 0.3; // курс 9 процедур = −30%

export type Plan = {
  title: string; // название рекомендованного комплекса
  promoPrice: number; // цена первого визита по акции, TJS
  promoFrom?: boolean; // если цена акции «от»
  course9PerProc: number | null; // цена за процедуру на курсе 9 (null = считает мастер)
  course9From: boolean; // цена курса с приставкой «от»
  exact: boolean; // true = подтверждённая цена, false = производная от «от»-цен
};

export function buildPlan(selected: ZoneId[]): Plan {
  const set = new Set(selected);

  // Всё тело: явный выбор или 4+ зон
  if (set.has('vse_telo') || selected.filter((z) => z !== 'vse_telo').length >= 4) {
    const per = Math.round((ZONE_BASE_PRICE.vse_telo as number) * (1 - COURSE9_DISCOUNT));
    return {
      title: 'Комплекс «Всё тело»',
      promoPrice: 350,
      course9PerProc: per,
      course9From: true,
      exact: false
    };
  }

  // Комплекс №1: ровно бикини + подмышки (подтверждённые цены)
  if (set.size === 2 && set.has('bikini') && set.has('podmyshki')) {
    return {
      title: 'Комплекс «Бикини + подмышки»',
      promoPrice: 100,
      course9PerProc: 245,
      course9From: false,
      exact: true
    };
  }

  // Ноги + бикини
  if (set.size === 2 && set.has('nogi') && set.has('bikini')) {
    const per = Math.round(310 * (1 - COURSE9_DISCOUNT));
    return {
      title: 'Комплекс «Ноги + бикини»',
      promoPrice: 150,
      promoFrom: true,
      course9PerProc: per,
      course9From: true,
      exact: false
    };
  }

  // Одна зона
  if (set.size === 1) {
    const zone = selected[0];
    const label = ZONES.find((z) => z.id === zone)?.label ?? 'Одна зона';
    const base = ZONE_BASE_PRICE[zone];
    return {
      title: label,
      promoPrice: zone === 'nogi' ? 150 : 75,
      course9PerProc: base ? Math.round(base * (1 - COURSE9_DISCOUNT)) : null,
      course9From: true,
      exact: false
    };
  }

  // Прочие комбинации 2–3 зон — индивидуальный комплекс
  return {
    title: 'Индивидуальный комплекс под твои зоны',
    promoPrice: 150,
    promoFrom: true,
    course9PerProc: null, // точный расчёт соберёт мастер
    course9From: true,
    exact: false
  };
}

// Калькулятор экономии за 5 лет (раздел 5.2 ТЗ)
export const METHOD_COST_PER_TIME: Record<string, number> = {
  shave: 15,
  sugaring: 80,
  cream: 25
};

export const FREQ_PER_YEAR: Record<string, number> = {
  every2_3days: 120,
  weekly: 52,
  every2_3weeks: 20,
  monthly: 12
};

export function fiveYearSpend(method: string, freq: string): number | null {
  const cost = METHOD_COST_PER_TIME[method];
  const times = FREQ_PER_YEAR[freq];
  if (!cost || !times) return null;
  return cost * times * 5;
}
