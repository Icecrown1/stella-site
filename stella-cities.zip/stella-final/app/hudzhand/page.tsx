import type { Metadata } from 'next';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import BookingForm from '@/components/BookingForm';
import { getStudiosByCity } from '@/lib/studios';
import { REVIEWS } from '@/lib/reviews';

const SITE_URL = 'https://laserstella.com';
const CITY = 'Худжанд' as const;

export const metadata: Metadata = {
  title: 'Лазерная эпиляция в Худжанде — студия STELLA, Гарантия результата',
  description:
    'Лазерная эпиляция в Худжанде: студия STELLA — проспект Р. Набиева, ЖК «Худжанд Сити», салон «Бурда», 2 этаж. Только мастера-женщины.',
  alternates: { canonical: `${SITE_URL}/hudzhand` }
};

export default function HudzhandPage() {
  const studios = getStudiosByCity(CITY);
  const reviews = REVIEWS.filter((r) => r.city === CITY);

  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Главная', item: SITE_URL },
      { '@type': 'ListItem', position: 2, name: 'Худжанд', item: `${SITE_URL}/hudzhand` }
    ]
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
      <Header />
      <main>
        <section className="bg-sand-50 py-14">
          <div className="container-page max-w-3xl">
            <nav className="text-xs text-ink-900/50 mb-6" aria-label="Хлебные крошки">
              <a href="/" className="hover:text-crimson-500">Главная</a>
              {' / '}
              <span>Худжанд</span>
            </nav>

            <h1 className="font-display font-extrabold text-3xl sm:text-4xl text-ink-900 leading-tight">
              Лазерная эпиляция в Худжанде
            </h1>
            <p className="mt-6 text-ink-900/75 leading-relaxed max-w-2xl">
              Студия STELLA в Худжанде работает по тому же прайсу и с той же
              Гарантией гладкости, что и студии в Душанбе. Все процедуры
              проводит женщина-косметолог, в приватной обстановке.
            </p>

            <a
              href="#zapis"
              className="mt-6 inline-block rounded-full bg-crimson-500 px-7 py-3.5 text-sm font-semibold text-sand-50 hover:bg-crimson-600 transition-colors"
            >
              Записаться в студию в Худжанде
            </a>

            <div className="mt-10 grid gap-4">
              {studios.map((s) => {
                const query = encodeURIComponent(`Худжанд, ${s.address}`);
                return (
                  <div key={s.id} className="rounded-xl2 bg-sand-100 p-6 max-w-md">
                    <p className="font-medium text-ink-900">{s.address}</p>
                    <p className="text-sm text-ink-900/60 mt-2">{s.landmark}</p>
                    <div className="mt-4 flex flex-wrap gap-3 text-sm">
                      <a
                        href={`https://yandex.com/maps/?text=${query}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-crimson-500 hover:underline"
                      >
                        Яндекс.Карты
                      </a>
                      <a
                        href={`https://2gis.tj/khujand/search/${query}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-crimson-500 hover:underline"
                      >
                        2GIS
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>

            {reviews.length > 0 && (
              <div className="mt-14">
                <h2 className="font-display font-bold text-xl text-ink-900 mb-5">
                  Отзывы клиенток из Худжанда
                </h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  {reviews.map((r) => (
                    <div key={r.name} className="rounded-xl2 bg-sand-100 p-6">
                      <div className="flex items-center gap-3 mb-3">
                        <img
                          src={r.avatar}
                          alt={r.name}
                          className="h-10 w-10 rounded-full object-cover"
                        />
                        <p className="text-sm font-medium text-ink-900">{r.name}</p>
                      </div>
                      <p className="text-sm text-ink-900/75 leading-relaxed">{r.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-10">
              <a href="/dushanbe" className="text-crimson-500 font-medium hover:underline">
                Студии в Душанбе →
              </a>
            </div>
          </div>
        </section>

        <BookingForm />
      </main>
      <Footer />
    </>
  );
}
